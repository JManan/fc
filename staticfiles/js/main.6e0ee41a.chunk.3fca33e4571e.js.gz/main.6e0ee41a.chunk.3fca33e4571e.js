(window.webpackJsonp = window.webpackJsonp || []).push([
  [0],
  [
    ,
    ,
    ,
    function(e, a, t) {
      e.exports = t.p + "static/media/Audaz flower.38ee4f04.webp";
    },
    function(e, a, t) {
      e.exports = t.p + "static/media/Audaz text_edited.331366f3.webp";
    },
    function(e, a, t) {
      e.exports = t.p + "static/media/aboutusimg.4755b96d.webp";
    },
    function(e, a, t) {
      e.exports = t.p + "static/media/member_img1.10a3f686.webp";
    },
    function(e, a, t) {
      e.exports = t(28);
    },
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    ,
    function(e, a, t) {},
    ,
    function(e, a, t) {},
    ,
    function(e, a, t) {},
    ,
    function(e, a, t) {},
    ,
    function(e, a, t) {},
    ,
    function(e, a, t) {},
    ,
    function(e, a, t) {
      "use strict";
      t.r(a);
      var n = t(0),
        c = t.n(n),
        l = t(2),
        o = t.n(l),
        s = (t(16), t(18), t(3)),
        r = t.n(s),
        i = t(4),
        m = t.n(i);
      var d = function() {
          return c.a.createElement(
            c.a.Fragment,
            null,
            c.a.createElement(
              "nav",
              { className: "navbar" },
              c.a.createElement(
                "div",
                { className: "mainlogo" },
                c.a.createElement("img", {
                  src: r.a,
                  alt: "",
                  className: "image1",
                }),
                c.a.createElement("img", {
                  src: m.a,
                  alt: "",
                  className: "image2",
                })
              ),
              c.a.createElement(
                "div",
                { className: "rightsidebar" },
                c.a.createElement(
                  "div",
                  { className: "enclosingsearch_box" },
                  c.a.createElement("i", {
                    className: "fa-solid fa-magnifying-glass",
                    id: "search",
                  }),
                  c.a.createElement("input", {
                    type: "text",
                    placeholder: "Search",
                    className: "searchbox",
                  })
                ),
                c.a.createElement(
                  "div",
                  { className: "bagsvg" },
                  c.a.createElement(
                    "svg",
                    {
                      xmlns: "http://www.w3.org/2000/svg",
                      version: "1.1",
                      width: "100%",
                      height: "100%",
                      viewBox: "5.7 0 105.5 126.1",
                      preserveAspectRatio: "xMinYMax meet",
                      "data-hook": "svg-icon-1",
                    },
                    c.a.createElement("path", {
                      d:
                        "M99.8 28.4c0-1.2-0.9-2-2.1-2h-15c0 3.2 0 7.6 0 8.2 0 1.5-1.2 2.6-2.6 2.9 -1.5 0.3-2.9-0.9-3.2-2.3 0-0.3 0-0.3 0-0.6 0-0.9 0-4.7 0-8.2H40.1c0 3.2 0 7.3 0 8.2 0 1.5-1.2 2.9-2.6 2.9 -1.5 0-2.9-0.9-3.2-2.3 0-0.3 0-0.3 0-0.6 0-0.6 0-5 0-8.2h-15c-1.2 0-2 0.9-2 2L8.3 124c0 1.2 0.9 2.1 2.1 2.1h96.3c1.2 0 2.1-0.9 2.1-2.1L99.8 28.4z",
                    }),
                    c.a.createElement("path", {
                      d:
                        "M59.1 5.9c-2.9 0-2 0-2.9 0 -2 0-4.4 0.6-6.4 1.5 -3.2 1.5-5.9 4.1-7.6 7.3 -0.9 1.8-1.5 3.5-1.8 5.6 0 0.9-0.3 1.5-0.3 2.3 0 1.2 0 2.1 0 3.2 0 1.5-1.2 2.9-2.6 2.9 -1.5 0-2.9-0.9-3.2-2.3 0-0.3 0-0.3 0-0.6 0-1.2 0-2.3 0-3.5 0-3.2 0.9-6.4 2-9.4 1.2-2.3 2.6-4.7 4.7-6.4 3.2-2.9 6.7-5 11.1-5.9C53.5 0.3 55 0 56.7 0c1.5 0 2.9 0 4.4 0 2.9 0 5.6 0.6 7.9 1.8 2.6 1.2 5 2.6 6.7 4.4 3.2 3.2 5.3 6.7 6.4 11.1 0.3 1.5 0.6 3.2 0.6 4.7 0 1.2 0 2.3 0 3.2 0 1.5-1.2 2.6-2.6 2.9s-2.9-0.9-3.2-2.3c0-0.3 0-0.3 0-0.6 0-1.2 0-2.6 0-3.8 0-2.3-0.6-4.4-1.8-6.4 -1.5-3.2-4.1-5.9-7.3-7.3 -1.8-0.9-3.5-1.8-5.9-1.8C61.1 5.9 59.1 5.9 59.1 5.9L59.1 5.9z",
                    }),
                    c.a.createElement(
                      "text",
                      {
                        x: "58.5",
                        y: "77",
                        dy: ".35em",
                        textAnchor: "middle",
                        className: "bGBBgJ",
                        "data-hook": "items-count",
                      },
                      "0"
                    )
                  )
                ),
                c.a.createElement("div", { className: "loginimgdiv" }),
                c.a.createElement(
                  "div",
                  {
                    className: "dropdownarrow",
                    onClick: function() {
                      document
                        .querySelector(".google_acc_bar")
                        .classList.contains("opened")
                        ? (document
                            .querySelector(".google_acc_bar")
                            .classList.remove("opened"),
                          document
                            .querySelector(".google_acc_bar")
                            .classList.add("closed"),
                          console.log("expin"))
                        : (document
                            .querySelector(".google_acc_bar")
                            .classList.add("opened"),
                          document
                            .querySelector(".google_acc_bar")
                            .classList.remove("closed"),
                          console.log("expout"));
                    },
                  },
                  c.a.createElement(
                    "svg",
                    {
                      xmlns: "http://www.w3.org/2000/svg",
                      viewBox: "0 0 26 26",
                    },
                    c.a.createElement(
                      "g",
                      null,
                      c.a.createElement(
                        "g",
                        null,
                        c.a.createElement("polygon", {
                          points:
                            "13,20.4 0,7.4 1.8,5.6 13,16.8 24.2,5.6 26,7.4   ",
                        })
                      )
                    )
                  )
                )
              )
            ),
            c.a.createElement(
              "div",
              { className: "menulist" },
              c.a.createElement("div", { className: "home" }, "Home"),
              c.a.createElement("div", { className: "audaz" }, "Audaz"),
              c.a.createElement("div", { className: "alamkarya" }, "Alamkarya"),
              c.a.createElement("div", { className: "crescendo" }, "Crescendo"),
              c.a.createElement("div", { className: "lagrace" }, "La Gr\xe2ce"),
              c.a.createElement("div", { className: "blog" }, "Blog"),
              c.a.createElement("div", { className: "forum" }, "Forum"),
              c.a.createElement("div", { className: "members" }, "Members"),
              c.a.createElement(
                "div",
                { className: "grouplist" },
                "Group List"
              ),
              c.a.createElement(
                "div",
                { className: "otherevents" },
                "Other Events"
              ),
              c.a.createElement(
                "div",
                { className: "contactus" },
                "Contact Us"
              ),
              c.a.createElement("div", { className: "aboutus" }, "About Us")
            ),
            c.a.createElement(
              "div",
              { className: "google_acc_bar" },
              c.a.createElement("div", { className: "profile" }, "Profile"),
              c.a.createElement("div", { className: "orders" }, "My Orders"),
              c.a.createElement(
                "div",
                { className: "address" },
                "My Addresses"
              ),
              c.a.createElement("div", { className: "wallet" }, "My Wallet"),
              c.a.createElement(
                "div",
                { className: "subscription" },
                "My Subscription"
              ),
              c.a.createElement(
                "div",
                { className: "wishlist" },
                "My Wishlist"
              ),
              c.a.createElement("div", { className: "account" }, "My Account"),
              c.a.createElement("hr", { className: "logout_linebrk" }),
              c.a.createElement("div", { className: "logout" }, "Logout")
            )
          );
        },
        u = (t(20), t(5)),
        g = t.n(u);
      var h = function(e) {
          return c.a.createElement(
            c.a.Fragment,
            null,
            c.a.createElement(
              "center",
              null,
              c.a.createElement("h1", null, "About Us")
            ),
            c.a.createElement(
              "center",
              null,
              c.a.createElement("h5", null, "Finding Inspiration in every Turn")
            ),
            c.a.createElement(
              "center",
              null,
              c.a.createElement(
                "p",
                null,
                "This is your About Page. This space is a great opportunity to give a full background on who you are, what you do and what your website has to offer. Double click on the text box to start editing your content and make sure to add all the relevant details you want site visitors to know."
              )
            ),
            c.a.createElement("img", {
              src: g.a,
              alt: "a pic for about us page",
              className: "aboutimg",
            }),
            c.a.createElement(
              "center",
              null,
              c.a.createElement("h1", { className: "story" }, "Our Story")
            ),
            c.a.createElement(
              "center",
              null,
              c.a.createElement(
                "p",
                null,
                "Every website has a story, and your visitors want to hear yours. This space is a great opportunity to give a full background on who you are, what your team does, and what your site has to offer. Double click on the text box to start editing your content and make sure to add all the relevant details you want site visitors to know.",
                c.a.createElement("br", null),
                c.a.createElement("br", null),
                "If you\u2019re a business, talk about how you started and share your professional journey. Explain your core values, your commitment to customers, and how you stand out from the crowd. Add a photo, gallery, or video for even more engagement."
              )
            ),
            c.a.createElement(
              "center",
              null,
              c.a.createElement("h1", null, "Team Members")
            )
          );
        },
        E = (t(22), t(24), t(6)),
        v = t.n(E),
        p = function(e) {
          var a = e.Members;
          return c.a.createElement(
            "div",
            { className: "all_members" },
            c.a.createElement("img", {
              src: v.a,
              alt: a.name,
              className: "mem_img",
            }),
            c.a.createElement("h4", null, a.name),
            c.a.createElement("h5", null, a.designation),
            c.a.createElement("p", { className: "member_desc" }, a.desc)
          );
        },
        b = function(e) {
          return c.a.createElement(
            "div",
            { className: "container" },
            e.memberList.map(function(e) {
              return c.a.createElement(p, { key: e.sno, Members: e });
            })
          );
        },
        y = function(e) {
          e &&
            e instanceof Function &&
            t
              .e(1)
              .then(t.bind(null, 29))
              .then(function(a) {
                var t = a.getCLS,
                  n = a.getFID,
                  c = a.getFCP,
                  l = a.getLCP,
                  o = a.getTTFB;
                t(e), n(e), c(e), l(e), o(e);
              });
        };
      t(26);
      var f = function() {
        return c.a.createElement(
          c.a.Fragment,
          null,
          c.a.createElement(
            "div",
            { className: "fcbitspilani" },
            "FASHION CLUB BITS PILANI"
          ),
          c.a.createElement("div", { className: "fcemail" }, "info@mysite.com"),
          c.a.createElement(
            "div",
            { className: "fccopyright" },
            "\xa92022 by Fashion Club BITS Pilani"
          )
        );
      };
      o.a.createRoot(document.getElementById("root")).render(
        c.a.createElement(
          c.a.StrictMode,
          null,
          c.a.createElement(d, null),
          c.a.createElement(h, null),
          c.a.createElement(b, {
            memberList: [
              {
                sno: 1,
                name: "name1",
                designation: "VP",
                desc:
                  "This is placeholder text. To change this content, double-click on the element and click Change Content.",
              },
              {
                sno: 2,
                name: "name2",
                designation: "VP",
                desc:
                  "This is placeholder text. To change this content, double-click on the element and click Change Content.",
              },
              {
                sno: 3,
                name: "name3",
                designation: "VP",
                desc:
                  "This is placeholder text. To change this content, double-click on the element and click Change Content.",
              },
              {
                sno: 4,
                name: "name4",
                designation: "VP",
                desc:
                  "This is placeholder text. To change this content, double-click on the element and click Change Content.",
              },
              {
                sno: 5,
                name: "name5",
                designation: "VP",
                desc:
                  "This is placeholder text. To change this content, double-click on the element and click Change Content.",
              },
              {
                sno: 6,
                name: "name6",
                designation: "VP",
                desc:
                  "This is placeholder text. To change this content, double-click on the element and click Change Content.",
              },
            ],
          }),
          c.a.createElement(f, null)
        )
      ),
        y();
    },
  ],
  [[7, 3, 2]],
]);
//# sourceMappingURL=main.6e0ee41a.chunk.js.4be1f4e9a82e.map
